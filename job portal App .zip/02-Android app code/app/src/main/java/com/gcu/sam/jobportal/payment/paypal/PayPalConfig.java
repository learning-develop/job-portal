package com.gcu.sam.jobportal.payment.paypal;

/**
 * Created by yash on 15/01/2018.
 */

public class PayPalConfig {
        public static final String PAYPAL_CLIENT_ID =  "INSERT_YOUR_PAYPAL_CLIENT_ID_HERE";
}
