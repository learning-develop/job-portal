package com.gcu.sam.jobportal.DTO;

import java.io.Serializable;

/**
 * Created by shubham on 16/8/17.
 */

public class BaseDTO implements Serializable {
}
